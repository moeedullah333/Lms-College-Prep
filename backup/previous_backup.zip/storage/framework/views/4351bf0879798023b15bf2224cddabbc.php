<!DOCTYPE html>
<html lang="en">

<head>

    <title>College Prep</title>

    <?php echo $__env->make('web.layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <header class="header_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="./index.php">
                            <div class="main_logo">
                                <img src="<?php echo e(asset('web/images/main-logo.png')); ?>" alt="">
                            </div>
                        </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">

                                <li class="nav-item">
                                    <a class="nav-link" href="./online-test-practices.php">Online Practice <span
                                            class="sr-only">(current)</span></a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="./virtual-classes.php">Virtual Classes</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="./college-counselling.php">College Counselling</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="./student-dashboard.php">Student Dashboard</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('web.blog.page')); ?>">Blogs</a>
                                </li>

                            </ul>

                            <div class="header_register_and_cart_btn">

                                
                                <?php if(isset(Auth::user()->id)): ?>
                                <a href="<?php echo e(route('user.logout')); ?>" class="btn main_action_btn" type="button">logout</a>   
                                <?php else: ?>
                                    <a href="<?php echo e(route('web.register.page')); ?>" class="btn main_action_btn" type="button">Register Now</a>
                                <?php endif; ?>
                                
                                <a href="javascript:;" class="header_cart_btn">
                                    <img src="<?php echo e(asset('web/images/cart-icon.png')); ?>" alt="">
                                    <span class="cart_item_number">2</span>
                                </a>

                            </div>

                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
<?php /**PATH D:\laravel\Gowri-Vemuri-College-Prep\resources\views/web/layouts/header.blade.php ENDPATH**/ ?>