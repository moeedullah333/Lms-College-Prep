<!-- Bootstrap Links -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- <script src="../simple-star-rating-input/rating.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>


<!-- Fontawesome links -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>


<!-- swiper links -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


<!-- AOS links -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>

<script src="<?php echo e(asset('admin_dashboard/js/custom.js')); ?>"></script>

</body>

</html>

<?php echo $__env->yieldPushContent('js'); ?>
<?php /**PATH /home/custom3mystaging/public_html/Gowri-Vemuri-College-Prep/resources/views/admin_dashboard/layouts/footer.blade.php ENDPATH**/ ?>