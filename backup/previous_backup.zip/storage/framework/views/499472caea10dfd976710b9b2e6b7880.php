

<?php $__env->startSection('content'); ?>
<section class="other_section_heading_top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section_main_subHeading">

                    <div class="section_heading">
                        <span class="main_boldHeading">Login</span>
                        <span class="main_heading pl-2">now</span>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="apply_now_section">
    <div class="container">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="register_form_main">
                    <?php if(\Session::has('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(\Session::get('error')); ?>

                    </div>
                <?php endif; ?>
                    <form action="<?php echo e(route('login.form')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                   
                        <div class="form-group">
                            <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" placeholder="Please Enter Email" name="email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <input type="password" class="form-control" id="password"
                                placeholder="Please Enter Password" name="password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="register_form_btns text-center">
                            <button type="submit" class="btn main_action_btn">Login</button>
                            <a href="javascript:;" class="btn main_action_btn" type="button">
                                <img src="<?php echo e(asset('web/images/google-logo.png')); ?>" alt="">
                            </a>
                        </div>
                  
                        <div class="text-center pt-2">
                            I don't have account. 
                            <a href="<?php echo e(route('web.register.page')); ?>">Go to Register</a>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custom3mystaging/public_html/Gowri-Vemuri-College-Prep/resources/views/web/pages/login.blade.php ENDPATH**/ ?>