
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
   <div class="row">
       <div class="col-md-12">
           <div class="page_top_bar">
               <div class="heading_with_icons">
                   <div class="sidebar_humburger_icon">

                       <span class="sidebar_btn" id="sidebar_navbtn"><i class="fa-solid fa-bars"></i></span>
                       <h2 class="main_page_heading">Update User</h2>
                   </div>

                   <div class="top_bar_right_part">
                       <div class="main_search_bar">
                           <input type="text" placeholder="Search here">
                       </div>

                       <div class="top_bar_icons">
                           <div>
                               <a href="javascript:;">
                                   <span class="header_user_icon"><i class="fa-solid fa-user"></i></span>
                               </a>
                           </div>

                           <div>
                               <a href="javascript:;">
                                   <span class="header_alert_icon"><i class="fa-solid fa-gear"></i></span>
                               </a>
                           </div>

                           <div class="position-relative">
                               <a href="">
                                   <span class="header_alert_icon"><i class="fa-solid fa-bell"></i></span>
                                   <span class="number_of_notifications">11</span>
                               </a>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>
   <div class="row">
       <div class="col-md-10 mx-auto">
           <div class="student_form_main">

               <form action="<?php echo e(route('admin.add.update.user',$user->id)); ?>" method="POST">
                   <?php echo csrf_field(); ?>
                   <div class="form-row mb-3">
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="text" class="form-control" placeholder="First Name" name="first_name" value="<?php echo e($user->first_name); ?>">
                           <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <p class="text-danger"><?php echo e($message); ?></p>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="text" class="form-control" placeholder="Last Name" name="last_name" value="<?php echo e($user->last_name); ?>">
                           <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <p class="text-danger"><?php echo e($message); ?></p>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                   </div>

                   <div class="form-row mb-3">
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="text" class="form-control" placeholder="Your Mobile No."
                               name="phone_number" value="<?php echo e($user->phone_number); ?>">
                       </div>
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="email" class="form-control" disabled placeholder="Your Email" name="email" value="<?php echo e($user->email); ?>">
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <p class="text-danger"><?php echo e($message); ?></p>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                   </div>

                   <div class="form-row mb-3">
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="text" class="form-control" placeholder="Parent First Name"
                               name="p_first_name" value="<?php echo e($user->parent_first_name); ?>">
                       </div>
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="text" class="form-control" placeholder="Parent Last Name"
                               name="p_last_name" value="<?php echo e($user->parent_last_name); ?>">
                       </div>
                   </div>

                   <div class="form-row mb-3">
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="text" class="form-control" placeholder="Phone Number 2"
                               name="phone_number_secondary" value="<?php echo e($user->phone_number_alternative); ?>">
                       </div>
                       <div class="col-12 col-sm-6 col-lg-6">
                           <input type="email" class="form-control" placeholder="Email 2" name="email_secondary" value="<?php echo e($user->email_alternative); ?>">
                       </div>
                   </div>

                   <div class="form-row mb-3">
                       <div class="col-12 col-sm-6 col-lg-6">
                           <div class="form-group">
                               <select class="form-control" id="grading" name="grade">
                                   <option>Grade</option>
                                   
                                   <option value="2" <?php echo e($user->grade == 2 ? "Selected" : ""); ?>>2</option>
                                   <option value="3" <?php echo e($user->grade == 3 ? "Selected" : ""); ?>>3</option>
                                   <option value="4" <?php echo e($user->grade == 4 ? "Selected" : ""); ?>>4</option>
                                   <option value="5" <?php echo e($user->grade == 5 ? "Selected" : ""); ?>>5</option>
                               </select>
                           </div>
                       </div>

                       <div class="col-12 col-sm-6 col-lg-6">
                           <div class="form-group">
                               <select class="form-control" id="course_name" name="course_name">
                                   <option>Course Name</option>
                                   <option value="test1" <?php echo e($user->course_name == "test1" ? "Selected" : ""); ?>>test1</option>
                                   <option value="test2" <?php echo e($user->course_name == "test2" ? "Selected" : ""); ?>>test2</option>
                                   <option value="test3" <?php echo e($user->course_name == "test3" ? "Selected" : ""); ?>>test3</option>
                                   <option value="test4" <?php echo e($user->course_name == "test4" ? "Selected" : ""); ?>>test4</option>
                               </select>
                           </div>
                       </div>
                   </div>

                   <div class="form-group mb-3">
                       <input type="text" class="form-control" id="school_name" placeholder="School Name" value="<?php echo e($user->school_name); ?>"
                           name="school_name">
                   </div>

                   <div class="form-group mb-3">
                       <input type="password" class="form-control" id="password" name="password"
                           placeholder="Please Enter Password" value="<?php echo e($user->password); ?>">
                       <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <p class="text-danger"><?php echo e($message); ?></p>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
                   
                   <div class="form-group mb-3">
                       <input type="password" class="form-control" id="c_password" name="c_password"
                           placeholder="Please Enter Password Again" value="<?php echo e($user->password); ?>">

                       <?php $__errorArgs = ['c_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <p class="text-danger"><?php echo e($message); ?></p>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>

                   <div class="form-row mb-3">
                       <div class="form-group col-12 col-sm-4 col-lg-4">
                           <select id="country" class="form-control" name="country"
                               aria-placeholder="Select Country">
                               <option value="null">Select</option>
                               <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($country->id); ?>" <?php echo e($country->id == $user->country_id ? "selected" : ""); ?>><?php echo e($country->name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                       </div>
                       <div class="form-group col-12 col-sm-4 col-lg-4">

                           <select name="state" id="getstate" class="form-control" aria-placeholder="">

                           </select>

                       </div>
                       <div class="form-group col-12 col-sm-4 col-lg-4">
                           <input type="text" class="form-control" value="<?php echo e($user->city); ?>"
                               name="city" id="city" placeholder="Enter City">
                       </div>
                   </div>

                   

                   <div class="">
                       <button type="submit" class="btn btn-primary">Update</button>
                   </div>

                  

               </form>

           </div>
       </div>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        let country = $('#country').val();
        let state_id = <?php echo json_encode($user->state_id, 15, 512) ?>;
        console.log(state_id);
        $('#getstate').empty();
        var data = {
            '_token': "<?php echo e(csrf_token()); ?>",
            'countryId': country
        };
        var url = "<?php echo e(route('user.register.getStates')); ?>";
        $.ajax({
            type: "post",
            url: url,
            data: data,
            dataType: "json",
            success: function(res) {
                if (res.status == true) {
                    $('#getstate').append(
                        `<option value='null' >Select</option>`
                    );
                    res.data.forEach(element => {
                      
                        $('#getstate').append(
                            `<option ${element.id == state_id ? "selected" : ""}  value='${element.id}' >${element.name}</option>`
                        );
                    });

                }
            }
        });

        $('#country').on('change', function() {
            let country = $(this).val();
            $('#getstate').empty();
            var data = {
                '_token': "<?php echo e(csrf_token()); ?>",
                'countryId': country
            };
            var url = "<?php echo e(route('user.register.getStates')); ?>";
            $.ajax({
                type: "post",
                url: url,
                data: data,
                dataType: "json",
                success: function(res) {
                    if (res.status == true) {
                        $('#getstate').append(
                            `<option value='null' >Select</option>`
                        );
                        res.data.forEach(element => {
                            $('#getstate').append(
                                `<option value='${element.id}' >${element.name}</option>`
                            );
                        });
                    }
                }
            });
        });

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin_dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\Gowri-Vemuri-College-Prep\resources\views/admin_dashboard/user_managment/update.blade.php ENDPATH**/ ?>