
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="page_top_bar">
                    <div class="heading_with_icons">
                        <div class="sidebar_humburger_icon">

                            <span class="sidebar_btn" id="sidebar_navbtn"><i class="fa-solid fa-bars"></i></span>
                            <h2 class="main_page_heading">Update Admin</h2>
                        </div>

                        <div class="top_bar_right_part">
                            <div class="main_search_bar">
                                <input type="text" placeholder="Search here">
                            </div>

                            <div class="top_bar_icons">
                                <div>
                                    <a href="javascript:;">
                                        <span class="header_user_icon"><i class="fa-solid fa-user"></i></span>
                                    </a>
                                </div>

                                <div>
                                    <a href="javascript:;">
                                        <span class="header_alert_icon"><i class="fa-solid fa-gear"></i></span>
                                    </a>
                                </div>

                                <div class="position-relative">
                                    <a href="">
                                        <span class="header_alert_icon"><i class="fa-solid fa-bell"></i></span>
                                        <span class="number_of_notifications">11</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="student_form_main">
                    <form action="<?php echo e(route('admin.add.update.admin',$user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-row mb-3">
                            <div class="col">
                                <label for="firstname">First Name</label>
                                <input type="text" id="firstname" class="form-control" placeholder="First name" value="<?php echo e($user->first_name); ?>" name="first_name">
                            </div>
                            <div class="col">
                                <label for="lastname">Last Name</label>
                                <input type="text" id="lastname" class="form-control" placeholder="Last name" value="<?php echo e($user->last_name); ?>" name="last_name">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                                placeholder="Please Enter Email" value="<?php echo e($user->email); ?>" name="email"> 
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Password</label>
                            <input type="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                                placeholder="Please Enter Password" value="<?php echo e($user->password); ?>" name="password"> 
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Confirm Password</label>
                            <input type="password" class="form-control" id="c_password" aria-describedby="emailHelp"
                                placeholder="Please Enter Confirm Password" name="" value="<?php echo e($user->password); ?>" name="c_password"> 
                        </div>

                        <div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\Gowri-Vemuri-College-Prep\resources\views/admin_dashboard/admin_managment/update.blade.php ENDPATH**/ ?>