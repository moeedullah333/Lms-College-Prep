@include('admin_dashboard.layouts.header')

@include('admin_dashboard.layouts.sidebar')

@yield('content')

@include('admin_dashboard.layouts.footer')