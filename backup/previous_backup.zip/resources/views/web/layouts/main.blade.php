@include('web.layouts.header')

@yield('content')

@include('web.layouts.footer')
