

// // const navBarBtn = document.getElementById("sidebar_navbtn");
// const closeNavBtn = document.getElementById("crossbtn_navbar");

// const close = document.getElementsByClassName("sidebar_btn");


// // close.addEventListener("click", openNav);

// closeNavBtn.addEventListener("click", closeNav());

// function openNav() {
//     // if(document.body.style.width == "600px"){
//     //     document.getElementById("mySideNav").style.width = "250px";
//     //     document.getElementById("mySideNav").style.marginLeft = "250px";
//     //     document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
//     // }

//         // document.getElementById("mySideNav").style.width = "250px";
//         // document.getElementById("mySideNav").style.marginLeft = "250px";
//         document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
//         console.log("hello");
// }


// function closeNav() {
//     document.getElementById("mySideNav").style.width = "0";
//     document.getElementById("mySideNav").style.marginLeft= "0";
//     document.body.style.backgroundColor = "white";
//     console.log("bye");
//   }

