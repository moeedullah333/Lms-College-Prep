<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blogs;
use App\Models\Cities;
use App\Models\Countries;
use App\Models\States;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin_dashboard.analytics');
    }

    public function user_listing()
    {
        $students = User::where('role', 2)->get();
        return view('admin_dashboard.user_managment.list', compact('students'));
    }

    public function user_add_page()
    {
        $countries = Countries::get();
        $states = States::get();
        $cities = Cities::get();
        return view('admin_dashboard.user_managment.add', compact(
            'countries',
            'states',
            'cities'
        ));
    }

    public function user_update_page($user_id)
    {
        $user = User::where('id', $user_id)->first();
        $countries = Countries::get();
        $states = States::get();
        $cities = Cities::get();
        return view('admin_dashboard.user_managment.update', compact(
            'user',
            'countries',
            'states',
            'cities'
        ));
    }

    public function user_add_update(Request $request, User $user)
    {
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'password' => 'required',
            'c_password' => 'required|same:password',
        ], [
            'c_password.required'  => 'The confirm password field is required.',
            'c_password.same'  => 'The confirm password field must match password.',
        ]);


        $msg = isset($user->id) ? "User Update Success" : "User Add Success";


        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone_number = $request->phone_number;
        $user->parent_first_name = $request->p_first_name;
        $user->parent_last_name = $request->p_last_name;
        $user->phone_number_alternative = $request->phone_number_secondary;
        $user->email_alternative = $request->email_secondary;
        $user->password = $request->password;
        $user->grade = $request->grade;
        $user->role = 2;
        $user->course_name = $request->course_name;
        $user->school_name = $request->school_name;
        $user->country_id  = $request->country;
        $user->state_id = $request->state;
        $user->city = $request->city;

        if ($user->save()) {

            return redirect()->route('admin.user_listing.page')->with('success', $msg);
        } else {
            return redirect()->route('admin.user_listing.page')->with('error', "Something Went Wrong!");
        }
    }

    public function user_delete($user_id)
    {
        $user = User::where('id', $user_id)->first();

        $user->delete();

        return redirect()->route('admin.user_listing.page')->with('success', "User Delete Success");
    }

    public function admin_listing()
    {
        $admins = User::where('role', 1)->get();
        return view('admin_dashboard.admin_managment.list', compact('admins'));
    }

    public function admin_add_page()
    {
        return view('admin_dashboard.admin_managment.add');
    }

    public function admin_update_page($user_id)
    {
        $user = User::where('id', $user_id)->first();

        return view('admin_dashboard.admin_managment.update', compact(
            'user',
        ));
    }

    public function admin_add_update(Request $request, User $user)
    {
        if (!isset($user->id)) {

            $request->validate([
                'first_name' => 'required',
                'last_name' => 'required',
                'password' => 'required',
                'c_password' => 'required|same:password',
            ], [
                'c_password.required'  => 'The confirm password field is required.',
                'c_password.same'  => 'The confirm password field must match password.',
            ]);
        }

        $msg = isset($user->id) ? "Admin Update Success" : "Admin Add Success";

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->password = $request->password;
        $user->email = $request->email;
        $user->role = 1;

        if ($user->save()) {

            return redirect()->route('admin.admin_listing.page')->with('success', $msg);
        } else {
            return redirect()->route('admin.admin_listing.page')->with('error', "Something Went Wrong!");
        }
    }

    public function admin_delete($user_id)
    {
        $user = User::where('id', $user_id)->first();

        $user->delete();

        return redirect()->route('admin.admin_listing.page')->with('success', "Admin Delete Success");
    }

    public function blog_listing()
    {
        $blogs = Blogs::get();
        return view('admin_dashboard.blogs_managment.list', compact('blogs'));
    }

    public function blog_add_page()
    {
        return view('admin_dashboard.blogs_managment.add');
    }

    public function blog_update_page($blog_id)
    {
        $blog = Blogs::where('id', $blog_id)->first();
        return view('admin_dashboard.blogs_managment.update', compact('blog'));
    }

    public function blog_add_update(Request $req, Blogs $blog)
    {
        $msg = isset($blog->id) ? "Blog Updated Success" : "Blog Added Success";

        if (!isset($blog->id)) {

            $validator =
                [
                    'title' => 'required',
                    'image' => 'required',
                    'description' => 'required',
                ];
            $validate = Validator::make($req->all(), $validator);


            if ($validate->fails()) {
                $response =
                    [
                        'success' => false,
                        'message' => $validate->errors()
                    ];
                return response()->json($response);
            }
        }

        if ($req->hasFile('image')) {

            if (isset($blog->id)) {
                if (File::exists($blog->image)) {
                    File::delete(public_path($blog->image));
                }
            }

            $image = $req->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('images/blogsimages'), $imageName);
            $imagepath = "images/blogsimages/" . $imageName;
            $blog->image = $imagepath;
        }

        $blog->user_id = auth()->user()->id;
        $blog->title = isset($req->title) ? $req->title : $blog->title;
        $blog->description = isset($req->description) ? $req->description : $blog->description;
        $blog->short_description = isset($req->short_description)  ? $req->short_description : $blog->short_description;

        if ($blog->save()) {
            return redirect()->route('admin.blog_listing.page')->with('success', $msg);
        } else {
            return redirect()->route('admin.blog_listing.page')->with('error', "Something Went Wrong!");
        }
    }

    public function blog_delete($blog_id)
    {
        $blog = Blogs::where('id', $blog_id)->first();
        if (File::exists($blog->image)) {
            File::delete(public_path($blog->image));
        }

        $blog->delete();

        return redirect()->route('admin.blog_listing.page')->with('success', "Blog Delete Success");
    }
}
